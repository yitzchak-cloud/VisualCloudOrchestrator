"""
nodes/resource/pubsub_topic/pubsub_topic.py
==========================================
Pub/Sub Topic node.

Parameters are loaded from topic_params.yaml (same directory).
Heavy Pulumi / Terraform logic is kept here because the topic node
is small enough not to warrant further splitting.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import ClassVar

import pulumi
import pulumi_gcp as gcp

from nodes.base_node import GCPNode, LogSource, Port, _resource_name
from nodes.port_types import PortType

logger = logging.getLogger(__name__)


@dataclass
class PubsubTopicNode(GCPNode):
    """
    Pub/Sub Topic — the core messaging hub.

    Publishers wire into the `publishers` input port.
    Subscriptions wire out of the `subscriptions` output port.

    Parameters loaded from topic_params.yaml:
      - name                       : topic resource name
      - message_retention_duration : how long messages are kept
      - kms_key_name               : CMEK key (optional)
    """

    # params_schema loaded automatically from topic_params.yaml

    inputs:  ClassVar = [Port("publishers",    PortType.TOPIC,        multi_in=True)]
    outputs: ClassVar = [Port("subscriptions", PortType.SUBSCRIPTION, multi=True)]

    node_color:  ClassVar = "#3b82f6"
    icon:        ClassVar = "pubsub"
    category:    ClassVar = "Messaging"
    description: ClassVar = "Pub/Sub Topic — the core messaging hub"

    # ------------------------------------------------------------------
    # Edge wiring
    # ------------------------------------------------------------------

    def resolve_edges(self, src_id, tgt_id, src_type, tgt_type, ctx) -> bool:
        if tgt_id == self.node_id and tgt_type == "PubsubTopicNode":
            ctx[self.node_id].setdefault("publisher_ids", []).append(src_id)
            return True
        if src_id == self.node_id and src_type == "PubsubTopicNode":
            ctx[tgt_id]["topic_id"] = self.node_id
            return True
        return False

    def dag_deps(self, ctx) -> list[str]:
        return []

    # ------------------------------------------------------------------
    # Pulumi
    # ------------------------------------------------------------------

    def pulumi_program(self, ctx, project, region, all_nodes, deployed_outputs):
        node_dict = ctx.get("node", {})
        props     = node_dict.get("props", {})

        def program() -> None:
            name = props.get("name") or _resource_name(node_dict)
            kms  = props.get("kms_key_name", "").strip() or None

            t = gcp.pubsub.Topic(
                self.node_id,
                name=name,
                message_retention_duration=props.get(
                    "message_retention_duration", "604800s"
                ),
                kms_key_name=kms,
                project=project,
            )
            pulumi.export("name", t.name)
            pulumi.export("id",   t.id)

        return program

    # ------------------------------------------------------------------
    # Terraform
    # ------------------------------------------------------------------

    @property
    def terraform_instance_prefix(self): return "topic"

    def terraform_call_vars(self, ctx, project, region, all_nodes):
        props = ctx.get("node", {}).get("props", {})
        return {
            "name":      f'"{props.get("name") or _resource_name(ctx.get("node", {}))}"',
            "retention": f'"{props.get("message_retention_duration", "604800s")}"',
        }

    # ------------------------------------------------------------------
    # Live outputs & logging
    # ------------------------------------------------------------------

    def live_outputs(self, pulumi_outputs, project, region) -> dict:
        return {"topic_name": pulumi_outputs.get("name", "")}

    def log_source(self, pulumi_outputs, project, region) -> LogSource | None:
        name = pulumi_outputs.get("name", "")
        if not name:
            return None
        return LogSource(
            filter=(
                f'resource.type="pubsub_topic"'
                f' AND resource.labels.topic_id="{name}"'
            ),
            project=project,
        )
